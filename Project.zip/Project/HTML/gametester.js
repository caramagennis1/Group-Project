// Store text content in variables
const text1 = "You’re walking down the hallway of your high school, surrounded by the sounds of clunky lockers slamming closed. The smell of cafeteria pizza is in the air, it's the last day of school before summer.";
const text2 = "Making it to your last class of the day, English, boke. You sit along with your best friends at the back of class, everyone is discussing their plans for the summer and suddenly the question is being asked to you. What are you up to?";

// Function to display text with delay
function displayText() {
    setTimeout(() => {
        document.getElementById("text1").textContent = text1;
        setTimeout(() => {
            document.getElementById("text2").textContent = text2;
        }, 2000);
    }, 1000);
    document.getElementById("text-container").style.display = "block"; // Show text container
}

// Function to handle button choices
function choosePath(choice) {
   
}

// Start the text display after page load
window.onload = displayText;
